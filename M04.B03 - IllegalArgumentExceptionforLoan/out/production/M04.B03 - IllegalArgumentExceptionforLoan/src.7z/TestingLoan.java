public class TestingLoan {

    public static void main(String[] args){

        //testing exception
        Loan l1 = new Loan(2.5, 5,1000);
        System.out.println(l1.getMonthlyPayment());
        System.out.println(l1.getTotalPayment());

    }
}
