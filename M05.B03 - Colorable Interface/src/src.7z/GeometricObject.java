public class GeometricObject {
}
