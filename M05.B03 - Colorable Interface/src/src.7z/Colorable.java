public interface Colorable {

     static void howToColor(){
         System.out.println("Color all four sides");
    }

}
