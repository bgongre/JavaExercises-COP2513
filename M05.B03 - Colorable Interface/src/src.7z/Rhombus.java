public class Rhombus extends GeometricObject implements Colorable {

    public Rhombus(){

    }

    public double getRhombusArea(double base, double height){
        double rhombusArea = base * height;
        return  rhombusArea;
    }
}
