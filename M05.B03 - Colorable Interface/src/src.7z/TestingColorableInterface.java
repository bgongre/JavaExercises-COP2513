public class TestingColorableInterface {

    public static void main(String args[]) {

    Object[] objArr = {new Object()}

    }

}
